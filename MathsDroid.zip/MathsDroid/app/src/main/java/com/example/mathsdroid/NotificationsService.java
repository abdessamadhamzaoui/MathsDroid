package com.example.mathsdroid;

import android.app.IntentService;
import android.content.Intent;

import androidx.annotation.Nullable;

public class NotificationsService extends IntentService {
    public NotificationsService() {
        super("NotificationsService");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        // Here goes code to get prime numbers
    }
}
